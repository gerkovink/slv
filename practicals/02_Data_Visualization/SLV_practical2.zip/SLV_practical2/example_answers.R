# Example answers
# Firstname Lastname
# 11-09-2021

# Load packages ----
library(ISLR)
library(tidyverse)

# Inspect data ----
head(Hitters)

# and so on...
